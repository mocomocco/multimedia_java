import javax.swing.JFrame;
public class SimpleWindow{
	public static void main(String argv[]){
	JFrame f = new JFrame("私が作った最初の窓");
	f.setSize(200,100);
	f.setVisible(true);	
	}
}